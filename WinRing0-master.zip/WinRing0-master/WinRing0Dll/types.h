#pragma once
#include <stdint.h>

using u8 = uint_fast8_t;
using u32 = uint_fast32_t;
using u64 = uint_fast64_t;
